using UnrealBuildTool;
using System.Collections.Generic;
public class VALOPRACTarget : TargetRules {
 public VALOPRACTarget(TargetInfo Target):base(Target){Type=TargetType.Game;DefaultBuildSettings=BuildSettingsVersion.V6;IncludeOrderVersion=EngineIncludeOrderVersion.Unreal5_7;ExtraModuleNames.Add("VALOPRAC");}
}
